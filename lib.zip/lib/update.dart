// import 'dart:js_util';
//
// import 'package:flutter/material.dart';
// import 'package:sqflite/sqflite.dart';
// import 'databaseHandler.dart';
// import 'user_model.dart';
//
// class Update extends StatefulWidget {
//   int? ids,number;
//   String? name,email,birthdate,website;
//   Function? getdata;
//
//   Update({
//     super.key,
//     this.ids,
//     this.name,
//     this.number,
//     this.email,
//     this.website,
//     this.birthdate,
//     this.getdata,
//   });
//
//   @override
//   State<Update> createState() => _UpdateState();
// }
//
// class _UpdateState extends State<Update> {
//   Database? _database;
//
//   TextEditingController nameContro = new TextEditingController();
//   TextEditingController emailContro = new TextEditingController();
//   TextEditingController numContro = new TextEditingController();
//   TextEditingController dateContro = new TextEditingController();
//   TextEditingController webContro = new TextEditingController();
//   @override
//   void initState() {
//     // TODO: implement initState
//     super.initState();
//
//     nameContro.text = widget.name!;
//     numContro.int= widget.number!;
//     emailContro.text = widget.email!;
//     dateContro.text = widget.birthdate;
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Padding(
//         padding: const EdgeInsets.fromLTRB(40, 50, 0, 0),
//         child: Container(
//           child: Column(children: [
//             TextField(
//               controller: nameContro,
//               decoration: InputDecoration(
//                   border: OutlineInputBorder(),
//                   labelText: 'Name',
//                   hintText: 'Enter Name'),
//             ),
//             SizedBox(
//               height: 20,
//             ),
//             TextField(
//               controller: emailContro,
//               decoration: InputDecoration(
//                 border: OutlineInputBorder(),
//                 labelText: 'email',
//                 hintText: 'Enter your valid email',
//               ),
//             ),
//             SizedBox(
//               height: 20,
//             ),
//             ElevatedButton(
//                 onPressed: () async {
//                   await update(widget.ids!);
//                   Navigator.of(context).pop();
//
//                   print(widget.ids);
//                   print(nameContro.text);
//                   print(emailContro.text);
//
//                   // Navigator.of(context).pop() ;
//                 },
//                 child: Text("Update")),
//           ]),
//         ),
//       ),
//     );
//   }
//
//   Future<Database?> openDB() async {
//     _database = await DatabaseHandler().openDB();
//     return _database;
//   }
//
//   Future<void> update(int id) async {
//     _database = await DatabaseHandler().openDB();
//     UserModel userModel =
//     new UserModel(nameContro.text.toString(), emailContro.text.toString());
//     await _database
//         ?.update("demo", userModel.toMap(), where: 'id=?', whereArgs: [id]);
//     widget.getdata != (true);
//     _database?.close();
//     setState(() {
//
//     });
//
//   }
// }
