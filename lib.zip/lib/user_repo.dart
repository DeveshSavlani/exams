import 'package:sqflite/sqflite.dart';

class UserRepo {
  void createTable(Database? db) {
    try{
      db?.execute("CREATE TABLE IF NOT EXISTS contactd(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, number  TEXT, email TEXT, website TEXT, birthdate TEXT)");
    }catch(e){
      print("table available");
    }
  }

  Future<List<Map<String, dynamic>>> getUsers(Database? db) async {
    final List<Map<String, dynamic>> maps = await db!.query('contactd');
    return maps;
  }
}
