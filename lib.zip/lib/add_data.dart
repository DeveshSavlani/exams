import 'dart:ffi';
import 'package:intl/intl.dart';
import 'package:examdb/addedit.dart';
import 'package:flutter/material.dart';
import 'databaseHandler.dart';
import 'user_model.dart';
import 'user_repo.dart';
import 'package:sqflite/sqflite.dart';

class add_data extends StatefulWidget {
  Function? getLoginData;
  add_data({super.key,this.getLoginData});

  @override
  State<add_data> createState() => _SecondState();
}

class _SecondState extends State<add_data> {
  TextEditingController idController = new TextEditingController();
  TextEditingController nameController = new TextEditingController();
  TextEditingController numberController = new TextEditingController();
  TextEditingController emailController = new TextEditingController();
  TextEditingController dateController = new TextEditingController();
  TextEditingController webController = new TextEditingController();

  Database? _database;
  List <Map<String, dynamic>>? userList;

  @override
  Widget build(BuildContext context) {

    return Scaffold(
        body:
        Padding(
          padding:EdgeInsets.fromLTRB(10, 60, 10, 10) ,

          child: Column(

            children: [
              Padding(padding: EdgeInsets.all(8),
                  child:TextField
                    (
                    controller: nameController,
                    decoration: InputDecoration(
                      border:OutlineInputBorder(),
                      labelText: 'Name',
                      hintText: 'Enter your  name',
                    ),
                  )
              ),
              Padding(padding: EdgeInsets.all(8),
                  child:TextField
                    (
                    controller: numberController,
                    decoration: InputDecoration(
                      border:OutlineInputBorder(),
                      labelText: 'Number',
                      hintText: 'Enter your  Number',
                    ),
                  )
              ),
              Padding(padding: EdgeInsets.all(8),
                  child:TextField
                    (
                    controller: emailController,
                    decoration: InputDecoration(
                      border:OutlineInputBorder(),
                      labelText: 'Email',
                      hintText: 'Enter your valid email',
                    ),
                  )
              ),
              Padding(padding: EdgeInsets.all(8),
                  child:TextField(
                    controller: dateController,
                    readOnly:  true,

                    decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        labelText: "Birth Date",
                        suffixIcon: IconButton(
                            icon: Icon(Icons.calendar_today),
                            onPressed: () async {
                              DateTime? pickedDate = await showDatePicker(
                                context: context,
                                initialDate: DateTime.now(),
                                //get today's date
                                firstDate: DateTime(
                                    2000),
                                //DateTime.now() - not to allow to choose before today.
                                lastDate: DateTime(2101),

                              );
                              String formatedDate = DateFormat('dd.MM.yyyy').format(pickedDate!);

                              print(formatedDate);
                              dateController.text = (formatedDate).toString();
                              setState(() {

                              });
                            }
                        )),

                  ),
              ),
              Padding(padding: EdgeInsets.all(8),
                  child:TextField
                    (
                    controller: webController,
                    decoration: InputDecoration(
                      border:OutlineInputBorder(),
                      labelText: 'Website',
                      hintText: 'Enter your website',
                    ),
                  )
              ),
              ElevatedButton(
                  onPressed: () async{
                    await insertDB();
                    Navigator.of(context).pop() ;
                  },
                  child: Text("Add")),

            ],
          ),
        )
    );
  }

  Future<Database?> openDB() async{
    _database = await DatabaseHandler().openDB();
    return _database;
  }
  Future<void> insertDB() async{
    _database = await openDB();
    UserRepo userRepo = new UserRepo();
    UserModel userModel = new UserModel(
        nameController.text.toString(),
        numberController.text.toString(),
        emailController.text.toString(),
        dateController.text.toString(),
      webController.text.toString()
        );

    await _database?.insert('contactd', userModel.toMap());
    await  _database?.close();

  }
}
