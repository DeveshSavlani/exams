import 'dart:ffi';

class UserModel {
  final String name;
  final String number;
  final String email;
  final String website;
  final String birthdate;


  UserModel(
      this.name,
      this.number,
      this.email,
      this.website,
      this.birthdate
      );

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'number': number,
      'email': email,
      'website':website,
      'birthdate':birthdate
    };
  }
}
