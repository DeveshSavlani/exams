import 'package:examdb/add_data.dart';
import 'package:examdb/addedit.dart';
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'user_repo.dart';
import 'databaseHandler.dart';


class contact extends StatefulWidget {



  @override
  State<contact> createState() => _ContactState();
}

class _ContactState extends State<contact> {
  List<Map<String, dynamic>> contactList=[];

  Database? _database;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getFromUser();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: Text('Contact List',style: TextStyle(color: Colors.black),),),

        floatingActionButton: FloatingActionButton.small(onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) =>addedit()),
          );
          print(contactList.length);
          print(contactList);
        },
          child: Icon(Icons.add),
        ),
        body: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(crossAxisAlignment:  CrossAxisAlignment.start,
            children: [
              ListView.builder(
                  shrinkWrap: true,
                  //itemCount: 4,
                  itemCount: contactList.length,
                  itemBuilder: (context,index)=>
                      Card( color:  Colors.white,
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
                          child: Row(
                            children: [
                              Container(width: 200,height: 50,
                                child: Row(crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [CircleAvatar(
                                    backgroundImage:NetworkImage('https://cdn.pixabay.com/photo/2016/11/21/11/17/model-1844729__340.jpg') ,
                                    radius: 50,
                                  ),
                                    SizedBox(width: 20,),
                                    Column(crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text("${contactList[index]['name']}",
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 25
                                          ),),
                                        Text("${contactList[index]['phone']}",
                                          style: TextStyle(
                                              color: Colors.grey
                                          ),
                                        ),
                                      ],
                                    )
                                  ],
                                ),
                              ),
    //                               Container(
    //                               child: ListView.builder(
    // scrollDirection: Axis.vertical,
    // physics: const NeverScrollableScrollPhysics(),
    // shrinkWrap: true,
    // //itemCount: 4,
    // itemCount: contactList.length,
    // itemBuilder: (context,index)=>
    // GestureDetector(onTap: (){
    // Navigator.push(
    // context,
    // MaterialPageRoute(builder: (context) => addedit(
    // contactList[index]['id'],
    // contactList[index]['name'],
    // contactList[index]['phone'],
    // contactList[index]['email'],
    // contactList[index]['website'],
    // contactList[index]['date']
    // )),
    // );
    // },
    //
    // )))],
                          ),
                        ),
                      ))
            ],
          ),
        )
    );
  }
  Future<Database?> openDB() async{
    _database = await DatabaseHandler().openDB();
    return _database;
  }

  Future<void> getFromUser() async {
    _database = await openDB();
    UserRepo usersRepo = new UserRepo();
    usersRepo.createTable(_database);
    contactList = await usersRepo.getUsers(_database);

    await _database?.close();
    setState(() {});
  }
}

