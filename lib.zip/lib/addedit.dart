import 'package:examdb/main.dart';
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'databaseHandler.dart';
import 'user_model.dart';
import 'user_repo.dart';

class addedit extends StatefulWidget {
  Function? getLoginData;
  addedit({super.key,this.getLoginData});
  bool isObscurePassword =true;
  @override
  State<addedit> createState() => _MyAppState();
}
class _MyAppState extends State<addedit> {
  TextEditingController idController = new TextEditingController();
  TextEditingController nameController = new TextEditingController();
  TextEditingController numberController = new TextEditingController();
  TextEditingController emailController = new TextEditingController();
  TextEditingController dateController = new TextEditingController();
  TextEditingController webController = new TextEditingController();

  Database? _database;
  List <Map<String, dynamic>>? userList;

  @override
  Widget build(BuildContext context) {
    return Scaffold(

        body: Container(
          padding: EdgeInsets.only(left: 15,top: 20,right: 15),
          child: GestureDetector(
            onTap:(){
              FocusScope.of(context).unfocus();
            },
            child: ListView(
              children: [
                Center(
                  child: Stack(
                    children: [
                      Container(
                        width: 130,
                        height: 130,
                        decoration: BoxDecoration(
                            border: Border.all(width: 4,color:Colors.white),
                            boxShadow: [
                              BoxShadow(
                                  spreadRadius: 2,
                                  blurRadius: 10,
                                  color: Colors.black.withOpacity(0.1)
                              )
                            ],
                            shape: BoxShape.circle,
                            image: DecorationImage(
                              fit: BoxFit.cover,
                              image: NetworkImage('https://cdn.pixabay.com/photo/2018/03/12/20/57/woman-3220835__340.jpg'),
                            )
                        ),
                      ),
                      Positioned(
                        bottom:0,
                        right:0,
                        child: Container(
                        height: 40,
                        width: 40,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            width: 4,
                            color: Colors.white
                          ),
                          color: Colors.blue
                        ),
                          child: Icon(
                            Icons.edit,
                            color:Colors.white,
                          ),
                        ),
                          )
              ],
          ),
                  ),
                SizedBox(height: 30),
                buildTextField('Phone Number', 'Dev', false),
                buildTextField('Email Address', 'dev@gmail.com', false),
                buildTextField('website', '-', false),
                buildTextField('birthdate', '15.04.1990', false),
                SizedBox(
                  height: 30,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    ElevatedButton(onPressed: (){}, child: Text("Edit",style: TextStyle(
                        fontSize: 23,letterSpacing: 2,
                        color: Colors.white
                    )),
                      style: ElevatedButton.styleFrom(
                          primary: Colors.blue,
                          padding: EdgeInsets.symmetric(horizontal: 150),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5))
                      ),
                    )
                  ],
                )
                ],
            ),
          ),
        )
    );
  }
  Widget buildTextField(String labelText,String Placeholder,bool isPasswordTextField){
    return Padding(
      padding: EdgeInsets.only(bottom: 30),
      child: TextField(
        obscureText: isPasswordTextField? true:false,
        decoration: InputDecoration(
            suffixIcon: isPasswordTextField?
            IconButton(
                icon: Icon(Icons.remove_red_eye,color: Colors.grey),
                onPressed: (){}):null,
            contentPadding: EdgeInsets.only(bottom: 5),
            labelText: labelText,
            floatingLabelBehavior: FloatingLabelBehavior.always,
            hintText: Placeholder,
            hintStyle: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.bold,
              color: Colors.grey,
            )
        ),
      ),
    );
  }
  Future<Database?> openDB() async{
    _database = await DatabaseHandler().openDB();
    return _database;
  }
  Future<void> insertDB() async{
    _database = await openDB();
    UserRepo userRepo = new UserRepo();
    UserModel userModel = new UserModel(
        nameController.text.toString(),
        numberController.text.toString(),
        emailController.text.toString(),
        dateController.text.toString(),
        webController.text.toString()
    );

    await _database?.insert('contactd', userModel.toMap());
    await  _database?.close();

  }
}
